# MathDocs CAS privacy policy

Effective: 11 November 2026. Applies to the MathDocs CAS Chrome extension and Google Docs Editor add-on. Publisher: Ahmed Abdirashid Ahmed. Contact: ahmed.abdirashid.a@gmail.com.

MathDocs provides mathematical editing, calculation and insertion in Google Docs. It does not run an independent formula server, sell user data, display advertising or include analytics or advertising trackers.

## Data used

MathDocs processes the formula you edit, calculated results, defined variables, the current document identifier, the selected formula image and the document location needed for insertion. The Chrome integration observes the current Docs interface and reads selected local formula images to reopen their mathematical source. It does not collect general browsing history or read the clipboard. Clipboard writing occurs when you choose Copy.

Keyboard, mouse, selection and scrolling events are used to respond to your commands and position the editor. MathDocs does not retain a history of keystrokes or use these events for analytics.

The standard visual editor performs algebra, plotting and geometry in a local browser worker. Its code, mathematics libraries and fonts are bundled. Google Apps Script receives formula images, source, result metadata, used variable values and session identifiers to save them to the current Google document. The separate legacy native-equation calculation menu performs its calculation on Google's Apps Script infrastructure.

## Storage and sharing

- Local browser storage holds recovery drafts, pending saves, variable drafts and a bounded recent-image cache. This storage belongs to the local Chrome profile or the Apps Script HTML origin. Drafts are separated by document and a generated user-specific workspace identifier; no email address is required for this identifier.
- Shared variables and saved formula revisions are stored using Google's document properties. Private workspace variables and sessions use Google's user properties, with document namespaces in the published-add-on build.
- Values needed to reproduce a saved calculation are included with that formula, including values originating from a private workspace. Other document editors can access saved formula content. Unrelated private variables are not included in calculation snapshots.
- Formulas embed their source and result in PNG metadata so that copies can remain editable. Copies and exports may therefore include this source, not only visible pixels. Other applications can remove the metadata when re-encoding an image.
- Google hosts the document, the Apps Script adapter and its platform diagnostics. Google's terms and privacy practices apply to those services. MathDocs does not add remote diagnostic uploads. Script errors may appear in Google's execution logs.

Data is used only to provide the mathematical editing and document features described above. MathDocs' use of data complies with the Chrome Web Store User Data Policy, including its Limited Use requirements: data is not used for advertising, sold, or transferred for unrelated purposes.

MathDocs' use and transfer of information received from Google APIs adheres to the Google API Services User Data Policy, including its Limited Use requirements.

## Retention and controls

Recovery drafts are overwritten by newer drafts in the same workspace. A confirmed save clears its matching recovery draft; an acknowledgement of an older save cannot clear a newer draft. Drafts older than 30 days are discarded the next time that workspace is opened. Pending-save recovery records require explicit dismissal or confirmation.

Removing the Chrome extension removes its extension storage. For the standalone editor, local drafts can be removed by clearing the browser's site data for the relevant Google Apps Script origin. Shared formula metadata and historical revisions remain with the script/document to support copied images and undo. Removing the browser extension does not remove those document contents or Google-stored settings. The script owner can remove script properties using Apps Script, and document editors control deletion of the document's visible formulas and copies.

No automatic mathematical correctness guarantee is made by a stored result. Document permissions control who can see or modify shared data; MathDocs does not bypass Google authorization.

## Questions and support

Contact ahmed.abdirashid.a@gmail.com or visit the public [support page](https://ahmedaccount.github.io/MathDocs-CAS-website/support.html). Do not send student names, private documents, credentials or sensitive formula data. The release publisher is responsible for keeping this policy and the store's privacy disclosures consistent with the deployed version.
