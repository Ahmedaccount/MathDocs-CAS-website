# MathDocs CAS 2.0.5 preview — installation

Den fulde løsning består af både Chrome-udvidelsen og Docs-add-on’en: Chrome giver matematikfelter og genveje direkte på arket, og add-on’en giver dokumentadgang og lagring. Opgradér begge til 2.0.5 ved en manuel testinstallation. Udgivelsesstatus findes i `CHROMEWEBSTORE.md` og på den offentlige installationsside.

Pakkerne er testversioner til lokal afprøvning. De er ikke publiceret i Chrome Web Store eller Google Workspace Marketplace.

## Prøv editoren uden Chrome-udvidelse

1. Udpak `MathDocs-Docs-Editor-2.0.5.zip`.
2. Åbn et testdokument i Google Docs. Vælg **Udvidelser → Apps Script**.
3. Opret/erstat filen `Code.gs` med pakkens `Code.gs`. Har dokumentet allerede egne scripts, skal de bevares og `onOpen` sammenflettes.
4. Opret en **HTML-fil** med navnet `Sidebar`. Indsæt hele indholdet af `Sidebar.html`.
5. Aktivér visning af manifestfilen i projektindstillingerne, og brug pakkens `appsscript.json`. Bevar nødvendige indstillinger fra eventuelle eksisterende scripts.
6. Gem og genindlæs Google-dokumentet. Klik et sted i dokumentteksten.
7. Vælg **MathDocs → Open editor · no Chrome extension needed**. Godkend de nødvendige Google-tilladelser i Googles egen dialog.
8. Skriv `1/2`, tryk mellemrum, skriv `+1/3`, og tryk mellemrum igen. **Enter** beregner `5/6` som en brøk på en ny linje. **Ctrl+Enter** (Mac: **Cmd+Enter**) indsætter den viste formel og resultatet i dokumentet.

Vælg et gemt MathDocs-billede, og åbn samme menu for at redigere det. For indsættelse midt i en sætning: placér markøren først, åbn editoren, og vælg **Placement → In text**. En ændring af det omgivende afsnit under redigeringen kræver, at placeringen vælges igen.

De store HTML- og scriptfiler kan også uploades som projektfiler med Googles officielle [clasp-værktøj](https://developers.google.com/apps-script/guides/clasp). Der er ingen projekt-ID'er eller credentials i pakken.

## Tilføj genvejen og editoren på dokumentarket

1. Udpak `MathDocs-CAS-2.0.5.zip` i en fast mappe.
2. Åbn `chrome://extensions`, aktivér **Udviklertilstand**, og vælg **Indlæs udpakket**.
3. Vælg mappen, der indeholder `manifest.json`.
4. Genindlæs testdokumentet med adapteren ovenfor installeret.
5. Klik først i dokumentteksten. Brug **Ctrl+M** på Windows/Linux/ChromeOS eller **Option+M** på Mac. Når feltet er åbent, beregner Ctrl+M på Windows; på Mac beholder Option+M fokus i feltet, og Option+S beregner. Enter beregner på begge platforme, mens Ctrl/Cmd+Enter indsætter.
6. Du kan også klikke på **∑** nederst i dokumentet eller på MathDocs-ikonet i Chromes udvidelsesmenu. Fastgør ikonet med tegnestiften for hurtig adgang.

Standardgenvejene har to taster og gælder kun i Docs/editoren. **Alt+P** (Mac: **Option+P**) plotter, **Alt+D** (Mac: **Option+D**) definerer variable, og **Alt+S/Option+S** virker fortsat til beregning. Ctrl+P/Cmd+P bevares til udskrivning; Ctrl+S/Cmd+S og Ctrl+Alt+M overtages heller ikke. Mac bruger Option/Alt, ikke Command, til M/S/D/P.

I `chrome://extensions/shortcuts` kan du valgfrit tildele en **ekstra** genvej under MathDocs CAS. Feltet er tomt ved en frisk installation, fordi standardgenvejene håndteres inde i dokumentet. En ekstra Chrome-genvej erstatter ikke standardgenvejene. Ved opgradering fra 2.0.1 kan Chrome have bevaret Ctrl+Shift+U eller Cmd+Shift+U; fjern den ekstra binding her, hvis du kun vil bruge de to-tasters standardgenveje.

Ved opgradering af en udpakket udvidelse: udpak den nye ZIP, vælg den nye mappe i Chrome eller erstat filerne i den allerede indlæste mappe, tryk **Genindlæs** på udvidelsen i `chrome://extensions`, og genindlæs derefter dokumentfanen. Det er ikke nok kun at genindlæse dokumentet.

Opgrader altid både Chrome-pakken og dokumentadapteren til samme version. Tilføjelsen bruger kun `docs.google.com/document/*` og browserens lokale lager. Deling af dokumentet installerer ikke browserudvidelsen hos andre.

## Kort accepttest i dit Google-dokument

1. Beregn og indsæt brøken fra trin 8 ovenfor. Kontrollér `5/6`, at prosaen er bevaret, og at Undo/Redo fungerer.
2. Markér det indsatte billede. Åbn MathDocs igen, ret `1/3` til `1/6`, beregn, og indsæt. Forvent `2/3` og ét opdateret billede.
3. Skriv en sætning, placér markøren midt i teksten, og vælg **Placement → In text**. Kontrollér at en kort formel passer ind i linjen.
4. På Windows: prøv Ctrl+M til åbning, skriv `2+3`, og tryk Ctrl+M igen. Forvent 5. På Mac: prøv Option+M til åbning/fokus og Option+S til beregning. Prøv Alt/Option+P med `x^2` til plot og ∑-knappen til åbning.
5. Åbn dokumentet på en anden konto uden MathDocs. Formlen skal kunne læses og udskrives. Redigering af den matematiske kilde kræver MathDocs-editoren.

Disse trin er en manuel accepttest, ikke en påstand om en gennemført test på din konto. Den automatiske test bruger Chromium med en simuleret Google-dokumenttjeneste.

## Hvad bliver indsat?

Den visuelle editor gemmer et **PNG-billede med redigeringsdata**, ikke et native Google-ligningsfelt. Samarbejdspartnere kan se billedet uden installation. De kan redigere udtrykket med den selvstændige MathDocs-editor, uden Chrome-udvidelsen, når add-on eller dokumentadapteren er tilgængelig og autoriseret for dem.

Googles dokumenterede [Docs API-requests](https://developers.google.com/workspace/docs/api/reference/rest/v1/documents/request) indeholder ingen ligningsoprettelse eller LaTeX-import. Apps Scripts [Equation-klasse](https://developers.google.com/apps-script/reference/document/equation) kan undersøge, kopiere og ændre dele af eksisterende ligninger, men tilbyder ingen fuld LaTeX-konvertering. Den begrænsede native funktion i MathDocs er derfor ikke en erstatning for dette manglende krav. Brug **Indsæt → Ligning** i Google Docs til en ligning, som alle kan redigere med Googles egne værktøjer; den nuværende MathDocs-editor konverterer ikke automatisk dertil.

## Samarbejde og gendannelse

- Fælles variable gemmes i dokumentet, når et felt indsættes. Private variable vælges eksplicit og er adskilt pr. bruger og dokument.
- Et gemt beregningsresultat indeholder en kopi af de benyttede variabelværdier, også når de kom fra en privat arbejdsflade. Urelaterede private variable medsendes ikke.
- Ved genindlæsning vises **Restore draft**, hvis der findes en lokal, ikke-gemt kladde. Kontrollér placeringen, især når kladden kom fra et andet felt.
- En ukendt gemmestatus må ikke udløse automatisk genindsættelse. Kontrollér først dokumentet; brug derefter den viste gendannelse eller Retry.

## Publicering til mange brugere

`MathDocs-Marketplace-2.0.5.zip` er til en standalone **Editor add-on**. Dens menu og brugerindstillinger er tilpasset denne distributionsform. Brug ikke Marketplace-varianten som en dokumentbundet testinstallation. Den bliver først en installation for almindelige brugere, når ejeren har oprettet udgivelsen og Google har gennemgået den. Se `docs/DISTRIBUTION.md` i repositoryet.

Efter offentlig udgivelse skal en almindelig bruger installere **MathDocs CAS fra Google Workspace Marketplace** og åbne editoren via **Udvidelser → MathDocs CAS**. Apps Script-filer skal da ikke kopieres manuelt. Chrome-udvidelsen installeres separat fra **Chrome Web Store** som den anden del af den fulde løsning. Har brugeren allerede Chrome-delen, installeres Docs-add-on’en; har brugeren Docs-add-on’en, installeres Chrome-delen. Læsere af dokumentet behøver ingen af delene. Der findes endnu ingen offentlige butikssider til disse pakker.
